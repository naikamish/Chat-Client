/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package message;

import java.awt.Color;
import java.awt.geom.GeneralPath;
import java.io.Serializable;

/**
 *
 * @author Amish Naik
 */
public class DoodlePath implements Serializable{
    private static final long serialVersionUID = 5950169519310163575L;
    private Color color;
    private GeneralPath generalPath;
    private int brushSize;
    
    public DoodlePath(GeneralPath generalPath, Color color, int brushSize){
        this.generalPath = generalPath;
        this.color = color;
        this.brushSize = brushSize;
    }
    
    public GeneralPath getGeneralPath(){
        return generalPath;
    }
    
    public Color getColor(){
        return color;
    }
    
    public int getBrushSize(){
        return brushSize;
    }
}