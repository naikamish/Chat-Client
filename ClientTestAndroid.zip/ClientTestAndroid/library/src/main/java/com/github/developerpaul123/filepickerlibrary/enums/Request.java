package com.github.developerpaul123.filepickerlibrary.enums;

/**
 * Created by Alireza Eskandarpour Shoferi on 2/24/2016.
 */
public enum Request {
    FILE, DIRECTORY
}
